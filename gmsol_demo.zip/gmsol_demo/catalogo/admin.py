from django.contrib import admin
from django.core.exceptions import ValidationError
from django.forms.models import BaseInlineFormSet
from .models import CategoriaProducto, Marca, Producto, Cliente, Telefono


@admin.register(CategoriaProducto)
class CategoriaProductoAdmin(admin.ModelAdmin):
    list_display = ("nombre", "activa")


@admin.register(Marca)
class MarcaAdmin(admin.ModelAdmin):
    list_display = ("nombre", "activa")


@admin.register(Producto)
class ProductoAdmin(admin.ModelAdmin):
    list_display = ("nombre", "categoria", "marca", "precio_compra", "precio_venta", "margen", "activo")
    list_filter = ("categoria", "activo")
    search_fields = ("nombre",)


class TelefonoFormSet(BaseInlineFormSet):
    def clean(self):
        super().clean()
        cargados = [
            f for f in self.forms
            if getattr(f, "cleaned_data", None) and not f.cleaned_data.get("DELETE")
        ]
        if not cargados:  # regla: un cliente tiene 1..n teléfonos
            raise ValidationError("El cliente debe tener al menos un teléfono.")


class TelefonoInline(admin.TabularInline):
    model = Telefono
    formset = TelefonoFormSet
    extra = 1


@admin.register(Cliente)
class ClienteAdmin(admin.ModelAdmin):
    list_display = ("nombre",)
    search_fields = ("nombre", "telefonos__numero")
    inlines = [TelefonoInline]
